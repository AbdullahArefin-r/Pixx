# PickaxeDrill

A fully configurable, **data-driven**, command-free 3x3 (or NxN) mining drill plugin for
Paper. Break the targeted block and the drill also mines the blocks around it, on a plane
that rotates to match the face you're mining (floor/ceiling vs. walls). Everything about
every drill - which items count as drills, their recipes, mining size, durability cost,
block filters, sneak behavior, permissions, worlds, cooldowns, particles, sounds, and
messages - is controlled entirely from `config.yml`. No Java changes are ever required to
add a new drill or change an existing one.

- **Minecraft:** Java Edition 1.21.11
- **Server:** Paper 1.21.11 (server-side only; players need no client mod)
- **Java:** 21
- **Commands:** none, intentionally. Everything happens through crafting, gameplay, and
  `config.yml`.

---

## ⚠️ Important: this repository is source, not a compiled build

This project was assembled in an environment with **no Java compiler (`javac`) and no
network access** to Maven Central or PaperMC's repository, so it was not possible to
compile or test a `.jar` here. Nothing was faked - there is no `PickaxeDrill.jar` in this
delivery. What you have is the **complete, buildable source project**. Building it
yourself (see below) requires an internet connection so Gradle can download the Paper API.

If you build it and hit an error, it's most likely one of:
1. A Paper API version string in `build.gradle.kts` that no longer exists (PaperMC's
   available Paper API versions change over time - see "Building" below).
2. A missing JDK 21 on your build machine.

Please build it, and if something doesn't compile, tell me the exact error and I'll fix it.

---

## Building

Requirements: JDK 21, internet access (for Gradle to fetch the Paper API and the
Shadow plugin), and either the Gradle wrapper (recommended - none is bundled here since
generating the wrapper jar requires network access this environment didn't have) or a
local Gradle 8.x install.

```bash
# From the project root, one of:
gradle wrapper --gradle-version 8.10        # generates gradlew/gradlew.bat once
./gradlew shadowJar                         # then, any time after
# or, without the wrapper:
gradle shadowJar
```

The output jar is written to `build/libs/PickaxeDrill-1.0.0.jar`. Copy that file into your
Paper server's `plugins/` folder.

**If the configured Paper API version fails to resolve:** open `build.gradle.kts` and
change the version string in the `paper-api` dependency to the latest one listed at
`https://repo.papermc.io/service/rest/repository/browse/maven-public/io/papermc/paper/paper-api/`.
The plugin's code only uses stable, long-standing Bukkit/Paper API (no NMS, no
version-specific internals), so any recent 1.21.x `paper-api` will compile it - a version
bump in one line is all that's ever needed.

---

## Installation

1. Build the jar (above), or obtain one from wherever you distribute it.
2. Drop `PickaxeDrill-1.0.0.jar` into your Paper server's `plugins/` folder.
3. Start the server once. On first startup the plugin generates
   `plugins/PickaxeDrill/config.yml` with full working examples for all six vanilla
   pickaxe tiers.
4. Edit `config.yml` to taste, then **restart the server** (or see "Auto-reload" below) to
   apply changes. There is no `/reload`-style command by design.
5. Craft a drill using the recipe you configured (defaults are the pickaxe's material
   surrounding a normal pickaxe of that tier, 3x3 crafting grid) and start mining.

---

## How crafting works

Each enabled drill with `recipe.enabled: true` registers a normal shaped crafting recipe -
nothing special from the player's perspective, it just shows up in the recipe book like any
other item. The **output item** is a normal pickaxe of the configured material, renamed and
tagged. Tagging uses Minecraft's `PersistentDataContainer` (an internal, invisible NBT-like
tag), not the display name or lore, so **renaming the drill in an anvil never breaks
detection** - it stays a working drill under any name.

A drill that isn't crafted (or given via `/give` from vanilla or another plugin using the
same material and no PDC tag) is just a normal pickaxe of that material and behaves exactly
like vanilla - PickaxeDrill never turns every Diamond Pickaxe into a drill automatically.

---

## Configuration structure

```
plugins/PickaxeDrill/
└── config.yml
```

`config.yml` has two parts:

1. **Global settings** at the top: `mining.max-size`, `debug.enabled`, `config.auto-reload`,
   and `messages.*`.
2. **`pickaxes:`** - one entry per drill. The key you use (`wooden`, `diamond`,
   `my_custom_drill`, anything) is the drill's internal id. The shipped defaults cover all
   six vanilla pickaxe tiers with complete, working settings; add as many additional
   entries as you like, with any id, using the same schema - **no Java code changes are
   ever needed** for a new drill.

### Per-drill option reference

| Path | Type | Meaning |
|---|---|---|
| `enabled` | bool | Master on/off switch for this drill. |
| `item.material` | Material | Base vanilla pickaxe material (`DIAMOND_PICKAXE`, etc.) - determines real mining speed/behavior, since the drill *is* that pickaxe, just tagged. |
| `item.name` | text | Display name. MiniMessage or legacy `&` codes (see below). |
| `item.lore` | list of text | Lore lines. |
| `item.custom-model-data` | int (optional) | Omit the line entirely to leave unset. |
| `item.enchantments` | map | `ENCHANTMENT_NAME: level` pairs applied to the crafted item. |
| `item.item-flags` | list | `ItemFlag` names, e.g. `HIDE_ENCHANTS`. |
| `item.unbreakable` | bool | If true, item never loses durability at all (overrides the whole `durability` section). |
| `recipe.enabled` | bool | If false, no recipe is registered for this drill. |
| `recipe.shape` | 1-3 rows of 1-3 chars | Standard shaped-recipe grid; use a space `" "` for empty cells. |
| `recipe.ingredients` | map | `CHAR: MATERIAL` pairs used in `shape`. |
| `mining.size` | odd int | 1, 3, 5, 7, 9... (capped by global `mining.max-size`). `1` = only the targeted block. |
| `durability.enabled` | bool | If false, this drill never loses durability at all. |
| `durability.amount-per-use` | int ≥ 0 | **Total** durability removed per activation (not per block - see below). |
| `durability.prevent-breaking` | bool | If true, the drill is held at 1 durability point instead of ever breaking. |
| `blocks.mode` | `BLACKLIST` / `WHITELIST` | See "Block filtering" below. |
| `blocks.materials` | list | Materials for that mode. |
| `sneak.required` | bool | If true, must sneak to activate the drill effect. |
| `sneak.disable-while-sneaking` | bool | If true (and `required` is false), sneaking mines a single block instead. |
| `permission.enabled` | bool | If true, `permission.node` is required. |
| `permission.node` | string | Permission node checked. |
| `worlds.mode` | `ALL` / `WHITELIST` / `BLACKLIST` | World restriction mode. |
| `worlds.list` | list of world names | Used by WHITELIST/BLACKLIST. |
| `cooldown.enabled` | bool | Rate-limit activations. |
| `cooldown.milliseconds` | long | Minimum time between activations, per player, per drill. |
| `particles.enabled` / `type` / `count` / `offset-x/y/z` / `speed` | - | Played once at the center block. `type` is a `org.bukkit.Particle` name. |
| `sounds.enabled` / `sound` / `volume` / `pitch` | - | Played once to the activating player. `sound` is an `org.bukkit.Sound` name. |
| `modes.survival` / `creative` / `adventure` | bool | Which gamemodes this drill works in. Spectators can never break blocks. |
| `tool.main-hand-only` | bool | See note below - reflects vanilla behavior, kept for completeness. |

An invalid `Material`/`Particle`/`Sound`/`Enchantment`/`ItemFlag` name anywhere in the
config is **never fatal**: it's logged as a clear warning (e.g. `Invalid material
'INVALID_ITEM' in diamond recipe.`) and that specific piece is skipped or disabled, while
everything else keeps loading normally. A drill with a genuinely invalid `item.material` is
the one thing that skips the *whole* drill, since there's nothing to build without it.

### Text formatting

Every text field (names, lore, messages) is parsed per-string:
- If it contains something that looks like a tag (`<...>`), it's parsed as
  **MiniMessage** - e.g. `"<aqua>Diamond Drill"`, `"<#ff5555>Custom Color"`, `<bold>...`.
- Otherwise it's parsed as **legacy `&` color codes** - e.g. `"&bDiamond Drill"`.

Mix and match freely between drills or even between lines - each string is judged on its
own.

### Durability: exactly one calculation per activation

This is the trickiest part of the spec and worth explaining precisely. A drill activation
might mine anywhere from 1 to `size*size` blocks, but must only ever cost
`durability.amount-per-use` points, **once**, no matter how many blocks were mined.

Vanilla Minecraft already fires exactly one durability event for the block you directly
targeted (the "center" block) once it finishes breaking. PickaxeDrill hooks that single
event and rewrites its amount to your configured total, instead of letting it apply
separately per block. The other 8 (or more) blocks in the drill's area are broken via
`Block#breakNaturally(...)`, a method that does not itself touch tool durability - so they
contribute **zero** additional durability loss. The net result: exactly one durability
change per activation, for exactly the amount you configured.

**Unbreaking interaction:** vanilla's single durability event already factors in the
Unbreaking enchantment's chance-based "skip this hit" roll. If that roll already reduced
the hit to zero damage, PickaxeDrill respects that and applies zero - it never overrides
Unbreaking's protection. If the roll says the hit *does* cost durability, PickaxeDrill
applies your configured total for that hit instead of vanilla's default of 1.

**`prevent-breaking: true`** holds the item at 1 durability point remaining forever instead
of letting it break, by clamping the applied damage on the hit that would otherwise destroy
it.

### Block filtering

`blocks.mode: BLACKLIST` (default) - `blocks.materials` lists blocks the drill **never**
mines. If the block you directly targeted is on this list, the drill doesn't activate at
all (vanilla single-block mining still happens). If a block *within* the extra mining area
is on the list, it's simply skipped and mining continues on the rest of the area.

`blocks.mode: WHITELIST` - only materials in `blocks.materials` may be mined by the extra
area. The originally-targeted block always breaks via normal vanilla rules either way,
regardless of filter mode.

The shipped default blacklist covers bedrock, portals, command blocks, structure/jigsaw
blocks, barriers, and reinforced deepslate.

### Sneak behavior

- `sneak.required: true` - normal mining breaks one block; sneak + mine triggers the drill.
- `sneak.required: false` + `sneak.disable-while-sneaking: true` - normal mining triggers
  the drill; sneak + mine breaks just one block (an escape hatch for precise digging).
- Both false (default) - the drill always triggers regardless of sneaking.

### Permissions

Not declared in `plugin.yml` (so there's nothing to pre-register), but fully functional:
set `permission.enabled: true` and `permission.node: "your.node"` per drill, and grant that
node with your permissions plugin (LuqkStuff, LuckPerms, etc.) as normal.

### Protection plugin compatibility

Every extra block the drill mines goes through a real `BlockBreakEvent`, fired and checked
for cancellation exactly like a normal player-initiated break, before anything is removed.
WorldGuard, claim plugins, and any other protection plugin listening to `BlockBreakEvent`
work exactly as they would for a normal single block break - if they cancel it, that block
is skipped and the drill continues with the rest of the area. The plugin never bypasses
protection. If your protection plugin hooks something other than `BlockBreakEvent` (some
very old or unusual plugins do), it may not be consulted for the *extra* blocks - that's an
inherent limitation of working through the standard event system rather than a workaround
choice, and is called out here rather than worked around by bypassing anything.

### Preventing recursive/chain mining

Blocks broken as part of a drill's extra area are broken through a path guarded against
re-triggering another drill activation - one player swing always produces exactly one drill
operation, never a chain reaction, even though those extra breaks go through the same
`BlockBreakEvent` machinery.

### Auto-reload

`config.auto-reload: true` starts a best-effort background file watcher that reloads
`config.yml` (and re-registers recipes) shortly after you save it, without a restart. It's
intentionally simple (a filesystem watch, not anything clever) per the spec's requirement
not to build an unreliable file-watching system; if it can't start (e.g. filesystem watching
unsupported in your environment) it logs a warning once and the plugin falls back to
startup-only loading. Leave it `false` and restart the server if you'd rather not run a
background watcher at all.

### Debug logging

`debug.enabled: true` logs one line per drill activation (drill id, target face, mining
size, blocks processed) to help verify behavior while you tune your config. Leave it
`false` on a live server.

---

## Common configuration mistakes

- **`mining.size` is even** (e.g. `4`) - drills need an odd size so there's a center block;
  invalid values fall back to `3` with a warning.
- **Recipe `shape` rows of different lengths** - the recipe is disabled (with a warning) but
  the rest of the drill (mining, durability, etc.) still works; the item just can't be
  crafted until you fix the shape.
- **A `shape` character with no matching `ingredients` entry** - same as above: recipe
  disabled, rest of the drill still works.
- **Typo in a `Material`/`Particle`/`Sound`/`Enchantment` name** - logged as a warning,
  that specific thing is skipped/disabled, everything else still loads.
- **Expecting `/pickaxedrill reload`** - there isn't one, by design. Restart the server, or
  turn on `config.auto-reload`.

---

## Troubleshooting

- **My drill doesn't craft.** Check the console at startup for `[PickaxeDrill]` warnings
  about that drill's recipe - an invalid shape or ingredient disables just that recipe.
- **My drill mines but a specific block doesn't break.** Check `blocks.mode`/`materials` -
  it's likely blacklisted (or not whitelisted).
- **Durability drops faster than expected.** Turn on `debug.enabled` and watch the console;
  each activation should log once. Also double check you're not confusing the *item's*
  visible damage bar (which reflects the durability point cost you configured) with "9
  blocks = 9 damage" - that's exactly the behavior this plugin avoids.
- **A drill works in creative but I expected durability loss there too.** Vanilla Minecraft
  never damages tools in Creative mode - this is unrelated to PickaxeDrill and applies to
  every tool in the game.

---

## Architecture (for anyone extending the plugin)

```
com.pickaxedrill
├── PickaxeDrillPlugin        - wiring only, no game logic
├── config/
│   ├── ConfigManager          - loads & validates config.yml
│   ├── DrillDefinition         - immutable per-drill model (nested records per section)
│   └── MessagesConfig          - raw message strings
├── drill/
│   ├── DrillManager             - id -> DrillDefinition registry, item resolution
│   └── DrillItemFactory          - builds ItemStacks, PDC tagging/reading
├── recipe/
│   └── RecipeManager              - registers/unregisters shaped recipes
├── mining/
│   └── MiningManager                - face resolution, NxN plane math, protection-safe breaking, recursion guard
├── manager/
│   ├── DurabilityManager              - single-calculation-per-activation logic
│   ├── CooldownManager                 - per-player/per-drill cooldowns
│   ├── ParticleManager                  - particle playback
│   ├── SoundManager                      - sound playback
│   └── MessageManager                     - configurable message sending
├── listener/
│   ├── BlockBreakListener                  - main gameplay hook
│   └── DurabilityListener                   - intercepts the one durability event per activation
└── util/
    ├── TextUtil                              - MiniMessage/legacy text parsing
    └── SafeParse                              - graceful Material/Particle/Sound/Enchantment/ItemFlag parsing
```

Nothing outside `config/` and `resources/config.yml` knows about specific drill ids,
materials, or behavior - adding a new drill type is a config-only change.
