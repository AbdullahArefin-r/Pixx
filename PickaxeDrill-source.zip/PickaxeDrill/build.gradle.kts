import org.gradle.jvm.toolchain.JavaLanguageVersion

plugins {
    id("java")
    id("com.gradleup.shadow") version "8.3.5"
}

group = "com.pickaxedrill"
version = "1.0.0"

repositories {
    mavenCentral()
    maven("https://repo.papermc.io/repository/maven-public/")
}

dependencies {
    // Paper API for Minecraft 1.21.11.
    // NOTE: If PaperMC has not yet published a 1.21.11-R0.1-SNAPSHOT artifact at the time you
    // build this (Paper API version strings track Mojang's mapped version), check
    // https://repo.papermc.io/service/rest/repository/browse/maven-public/io/papermc/paper/paper-api/
    // and adjust this version string to the latest published 1.21.x release you want to target.
    // The plugin code itself only uses stable Bukkit/Paper API (no version-specific internals),
    // so it will compile against any recent 1.21.x paper-api with at most a version bump here.
    compileOnly("io.papermc.paper:paper-api:1.21.11-R0.1-SNAPSHOT")
}

java {
    toolchain.languageVersion.set(JavaLanguageVersion.of(21))
}

tasks {
    compileJava {
        options.encoding = "UTF-8"
        options.release.set(21)
    }

    processResources {
        val props = mapOf("version" to project.version)
        inputs.properties(props)
        filteringCharset = "UTF-8"
        filesMatching("plugin.yml") {
            expand(props)
        }
    }

    shadowJar {
        archiveBaseName.set("PickaxeDrill")
        archiveClassifier.set("")
        archiveVersion.set(project.version.toString())
    }

    build {
        dependsOn(shadowJar)
    }
}
