rootProject.name = "PickaxeDrill"

pluginManagement {
    repositories {
        gradlePluginPortal()
        mavenCentral()
    }
}
