package com.pickaxedrill;

import com.pickaxedrill.config.ConfigManager;
import com.pickaxedrill.drill.DrillItemFactory;
import com.pickaxedrill.drill.DrillManager;
import com.pickaxedrill.listener.BlockBreakListener;
import com.pickaxedrill.listener.DurabilityListener;
import com.pickaxedrill.manager.CooldownManager;
import com.pickaxedrill.manager.DurabilityManager;
import com.pickaxedrill.manager.MessageManager;
import com.pickaxedrill.manager.ParticleManager;
import com.pickaxedrill.manager.SoundManager;
import com.pickaxedrill.mining.MiningManager;
import com.pickaxedrill.recipe.RecipeManager;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.IOException;
import java.nio.file.FileSystems;
import java.nio.file.Path;
import java.nio.file.StandardWatchEventKinds;
import java.nio.file.WatchKey;
import java.nio.file.WatchService;

/**
 * PickaxeDrill - a fully configurable, data-driven, command-free 3x3 (or NxN) mining drill
 * plugin for Paper 1.21.11. See config.yml and README.md for the full option reference.
 *
 * This class only wires the pieces together; all real behavior lives in the config/drill/
 * recipe/mining/manager/listener packages, each of which is unit-testable in isolation and
 * none of which hard-codes any drill-specific behavior - everything is driven by config.yml.
 */
public final class PickaxeDrillPlugin extends JavaPlugin {

    private ConfigManager configManager;
    private DrillItemFactory itemFactory;
    private DrillManager drillManager;
    private RecipeManager recipeManager;
    private MiningManager miningManager;
    private DurabilityManager durabilityManager;
    private CooldownManager cooldownManager;
    private ParticleManager particleManager;
    private SoundManager soundManager;
    private MessageManager messageManager;

    private Thread watcherThread;
    private volatile boolean watcherRunning = false;

    @Override
    public void onEnable() {
        this.configManager = new ConfigManager(this);
        configManager.load();

        this.itemFactory = new DrillItemFactory(this);
        this.drillManager = new DrillManager(configManager, itemFactory);
        this.recipeManager = new RecipeManager(this, drillManager, itemFactory);
        this.miningManager = new MiningManager(getLogger(), configManager.isDebugEnabled());
        this.durabilityManager = new DurabilityManager();
        this.cooldownManager = new CooldownManager();
        this.particleManager = new ParticleManager();
        this.soundManager = new SoundManager();
        this.messageManager = new MessageManager(configManager.getMessages());

        recipeManager.registerAll();

        getServer().getPluginManager().registerEvents(
                new BlockBreakListener(drillManager, miningManager, durabilityManager, cooldownManager,
                        particleManager, soundManager, messageManager),
                this);
        getServer().getPluginManager().registerEvents(
                new DurabilityListener(drillManager, durabilityManager, messageManager),
                this);

        if (configManager.isAutoReload()) {
            startConfigWatcher();
        }

        getLogger().info("PickaxeDrill enabled: " + drillManager.getAllDrills().size()
                + " drill(s) loaded, no commands registered.");
    }

    @Override
    public void onDisable() {
        stopConfigWatcher();
        if (recipeManager != null) {
            recipeManager.unregisterAll();
        }
        getLogger().info("PickaxeDrill disabled.");
    }

    /**
     * Reloads config.yml, re-parses every drill, and re-registers recipes to match. Called on
     * startup always, and additionally whenever the optional file watcher (config.auto-reload)
     * detects a change. There is intentionally no in-game command to trigger this (spec
     * section 28) - it is startup-only unless auto-reload is explicitly enabled.
     */
    private void reload() {
        configManager.load();
        messageManager.update(configManager.getMessages());
        miningManager.setDebug(configManager.isDebugEnabled());
        recipeManager.registerAll();
        getLogger().info("PickaxeDrill config reloaded: " + drillManager.getAllDrills().size() + " drill(s) loaded.");
    }

    /**
     * Best-effort, optional file watcher for config.yml, only started when config.auto-reload
     * is true. Per spec section 28 this must not be a complex/unreliable mechanism: it simply
     * watches the plugin data folder for a modify event on config.yml and triggers a reload on
     * the main thread shortly after. If anything goes wrong, it logs and gives up quietly
     * rather than destabilizing the plugin - auto-reload is a convenience, not a guarantee.
     */
    private void startConfigWatcher() {
        Path dataFolder = getDataFolder().toPath();
        try {
            WatchService watchService = FileSystems.getDefault().newWatchService();
            dataFolder.register(watchService, StandardWatchEventKinds.ENTRY_MODIFY);
            watcherRunning = true;
            watcherThread = new Thread(() -> runWatcherLoop(watchService), "PickaxeDrill-ConfigWatcher");
            watcherThread.setDaemon(true);
            watcherThread.start();
        } catch (IOException e) {
            getLogger().warning("[PickaxeDrill] Could not start config auto-reload watcher: " + e.getMessage()
                    + ". Falling back to startup-only config loading.");
        }
    }

    private void runWatcherLoop(WatchService watchService) {
        try {
            while (watcherRunning) {
                WatchKey key = watchService.take();
                boolean relevant = key.pollEvents().stream()
                        .anyMatch(ev -> ev.context().toString().equals("config.yml"));
                key.reset();
                if (relevant) {
                    // Hop back onto the main thread - all Bukkit/Paper API calls must be sync.
                    getServer().getScheduler().runTask(this, this::reload);
                }
            }
        } catch (InterruptedException ignored) {
            Thread.currentThread().interrupt();
        } catch (Exception e) {
            getLogger().warning("[PickaxeDrill] Config auto-reload watcher stopped unexpectedly: " + e.getMessage());
        }
    }

    private void stopConfigWatcher() {
        watcherRunning = false;
        if (watcherThread != null) {
            watcherThread.interrupt();
        }
    }
}
