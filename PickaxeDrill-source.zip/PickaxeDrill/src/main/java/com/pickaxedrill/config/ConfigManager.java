package com.pickaxedrill.config;

import com.pickaxedrill.util.SafeParse;
import com.pickaxedrill.util.TextUtil;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.logging.Logger;

/**
 * Loads config.yml into validated, immutable {@link DrillDefinition} objects. Every value is
 * defensively parsed: a bad/missing entry logs a warning and falls back to a safe default (or,
 * for a genuinely unusable drill such as an unrecognized item material, causes just that one
 * drill to be skipped) rather than throwing and taking the whole plugin down.
 */
public final class ConfigManager {

    private final JavaPlugin plugin;
    private final Logger logger;

    private Map<String, DrillDefinition> drills = new LinkedHashMap<>();
    private MessagesConfig messages;
    private int globalMaxSize = 9;
    private boolean debugEnabled = false;
    private boolean autoReload = false;

    public ConfigManager(JavaPlugin plugin) {
        this.plugin = plugin;
        this.logger = plugin.getLogger();
    }

    /** Loads (or reloads) everything from the currently-in-memory plugin config. */
    public void load() {
        plugin.saveDefaultConfig();
        plugin.reloadConfig();
        FileConfiguration config = plugin.getConfig();

        this.globalMaxSize = Math.max(1, config.getInt("mining.max-size", 9));
        this.debugEnabled = config.getBoolean("debug.enabled", false);
        this.autoReload = config.getBoolean("config.auto-reload", false);
        this.messages = loadMessages(config);

        Map<String, DrillDefinition> parsed = new LinkedHashMap<>();
        ConfigurationSection pickaxesSection = config.getConfigurationSection("pickaxes");
        if (pickaxesSection == null) {
            logger.warning("[PickaxeDrill] No 'pickaxes' section found in config.yml - no drills will be available.");
        } else {
            for (String id : pickaxesSection.getKeys(false)) {
                ConfigurationSection section = pickaxesSection.getConfigurationSection(id);
                if (section == null) {
                    continue;
                }
                try {
                    DrillDefinition definition = parseDrill(id, section);
                    if (definition != null) {
                        parsed.put(id, definition);
                    }
                } catch (Exception e) {
                    logger.warning("[PickaxeDrill] Failed to load drill '" + id + "': " + e.getMessage()
                            + ". Skipping this drill.");
                }
            }
        }
        this.drills = parsed;

        if (debugEnabled) {
            logger.info("[PickaxeDrill] Loaded " + drills.size() + " drill definition(s): " + drills.keySet());
        }
    }

    private MessagesConfig loadMessages(FileConfiguration config) {
        Map<String, String> map = new LinkedHashMap<>();
        ConfigurationSection section = config.getConfigurationSection("messages");
        if (section != null) {
            for (String key : section.getKeys(false)) {
                map.put(key, section.getString(key, ""));
            }
        }
        return new MessagesConfig(map);
    }

    private DrillDefinition parseDrill(String id, ConfigurationSection section) {
        boolean enabled = section.getBoolean("enabled", true);

        DrillDefinition.ItemSettings item = parseItem(id, section.getConfigurationSection("item"));
        if (item == null) {
            // Invalid/missing base material makes this drill unusable - skip it entirely,
            // but keep loading everything else (spec section 33).
            logger.warning("[PickaxeDrill] Drill '" + id + "' has no valid item.material - skipping this drill.");
            return null;
        }

        DrillDefinition.RecipeSettings recipe = parseRecipe(id, section.getConfigurationSection("recipe"));

        int size = section.getInt("mining.size", 3);
        if (size % 2 == 0 || size < 1) {
            logger.warning("[PickaxeDrill] Drill '" + id + "' has invalid mining.size " + size
                    + " (must be a positive odd number). Falling back to 3.");
            size = 3;
        }
        if (size > globalMaxSize) {
            logger.warning("[PickaxeDrill] Drill '" + id + "' mining.size " + size
                    + " exceeds mining.max-size " + globalMaxSize + ". Clamping to " + globalMaxSize + ".");
            size = globalMaxSize % 2 == 0 ? globalMaxSize - 1 : globalMaxSize;
        }

        DrillDefinition.DurabilitySettings durability = new DrillDefinition.DurabilitySettings(
                section.getBoolean("durability.enabled", true),
                Math.max(0, section.getInt("durability.amount-per-use", 1)),
                section.getBoolean("durability.prevent-breaking", false)
        );

        DrillDefinition.BlockFilter blockFilter = parseBlockFilter(id, section.getConfigurationSection("blocks"));

        DrillDefinition.SneakSettings sneak = new DrillDefinition.SneakSettings(
                section.getBoolean("sneak.required", false),
                section.getBoolean("sneak.disable-while-sneaking", false)
        );

        DrillDefinition.PermissionSettings permission = new DrillDefinition.PermissionSettings(
                section.getBoolean("permission.enabled", false),
                section.getString("permission.node", "pickaxedrill." + id)
        );

        DrillDefinition.WorldSettings worlds = parseWorlds(section.getConfigurationSection("worlds"));

        DrillDefinition.CooldownSettings cooldown = new DrillDefinition.CooldownSettings(
                section.getBoolean("cooldown.enabled", false),
                Math.max(0, section.getLong("cooldown.milliseconds", 250))
        );

        DrillDefinition.ParticleSettings particles = parseParticles(id, section.getConfigurationSection("particles"));
        DrillDefinition.SoundSettings sounds = parseSounds(id, section.getConfigurationSection("sounds"));

        DrillDefinition.ModeSettings modes = new DrillDefinition.ModeSettings(
                section.getBoolean("modes.survival", true),
                section.getBoolean("modes.creative", true),
                section.getBoolean("modes.adventure", false)
        );

        boolean mainHandOnly = section.getBoolean("tool.main-hand-only", true);

        return new DrillDefinition(id, enabled, item, recipe, size, durability, blockFilter, sneak,
                permission, worlds, cooldown, particles, sounds, modes, mainHandOnly);
    }

    private DrillDefinition.ItemSettings parseItem(String id, ConfigurationSection section) {
        if (section == null) {
            return null;
        }
        Material material = SafeParse.material(logger, "drill '" + id + "' item.material",
                section.getString("material"));
        if (material == null) {
            return null;
        }

        String rawName = section.getString("name", id);
        var name = TextUtil.parse(rawName);
        var lore = TextUtil.parseList(section.getStringList("lore"));

        Integer customModelData = section.isSet("custom-model-data")
                ? section.getInt("custom-model-data") : null;

        Map<Enchantment, Integer> enchantments = new LinkedHashMap<>();
        ConfigurationSection enchSection = section.getConfigurationSection("enchantments");
        if (enchSection != null) {
            for (String key : enchSection.getKeys(false)) {
                Enchantment enchantment = SafeParse.enchantment(logger, "drill '" + id + "' enchantments", key);
                if (enchantment != null) {
                    enchantments.put(enchantment, Math.max(1, enchSection.getInt(key, 1)));
                }
            }
        }

        Set<ItemFlag> flags = new LinkedHashSet<>();
        for (String flagName : section.getStringList("item-flags")) {
            ItemFlag flag = SafeParse.itemFlag(logger, "drill '" + id + "' item-flags", flagName);
            if (flag != null) {
                flags.add(flag);
            }
        }

        boolean unbreakable = section.getBoolean("unbreakable", false);

        return new DrillDefinition.ItemSettings(material, name, lore, customModelData, enchantments, flags, unbreakable);
    }

    private DrillDefinition.RecipeSettings parseRecipe(String id, ConfigurationSection section) {
        if (section == null || !section.getBoolean("enabled", true)) {
            return new DrillDefinition.RecipeSettings(false, List.of(), Map.of());
        }

        List<String> shape = section.getStringList("shape");
        if (shape.isEmpty() || shape.size() > 3) {
            logger.warning("[PickaxeDrill] Drill '" + id + "' recipe.shape must have 1-3 rows. "
                    + "Disabling recipe for this drill.");
            return new DrillDefinition.RecipeSettings(false, List.of(), Map.of());
        }
        int width = shape.get(0).length();
        if (width < 1 || width > 3) {
            logger.warning("[PickaxeDrill] Drill '" + id + "' recipe.shape rows must be 1-3 characters. "
                    + "Disabling recipe for this drill.");
            return new DrillDefinition.RecipeSettings(false, List.of(), Map.of());
        }
        for (String row : shape) {
            if (row.length() != width) {
                logger.warning("[PickaxeDrill] Drill '" + id + "' recipe.shape rows must all be the same "
                        + "length. Disabling recipe for this drill.");
                return new DrillDefinition.RecipeSettings(false, List.of(), Map.of());
            }
        }

        Map<Character, Material> ingredients = new LinkedHashMap<>();
        ConfigurationSection ingredientsSection = section.getConfigurationSection("ingredients");
        if (ingredientsSection != null) {
            for (String key : ingredientsSection.getKeys(false)) {
                if (key.length() != 1) {
                    continue;
                }
                Material material = SafeParse.material(logger, "drill '" + id + "' recipe.ingredients",
                        ingredientsSection.getString(key));
                if (material != null) {
                    ingredients.put(key.charAt(0), material);
                }
            }
        }

        // Every non-space character used in the shape must have a matching ingredient.
        for (String row : shape) {
            for (char c : row.toCharArray()) {
                if (c != ' ' && !ingredients.containsKey(c)) {
                    logger.warning("[PickaxeDrill] Drill '" + id + "' recipe.shape uses '" + c
                            + "' but no matching ingredient is defined. Disabling recipe for this drill.");
                    return new DrillDefinition.RecipeSettings(false, List.of(), Map.of());
                }
            }
        }

        return new DrillDefinition.RecipeSettings(true, shape, ingredients);
    }

    private DrillDefinition.BlockFilter parseBlockFilter(String id, ConfigurationSection section) {
        DrillDefinition.FilterMode mode = DrillDefinition.FilterMode.BLACKLIST;
        Set<Material> materials = new LinkedHashSet<>();
        if (section != null) {
            String modeRaw = section.getString("mode", "BLACKLIST");
            try {
                mode = DrillDefinition.FilterMode.valueOf(modeRaw.trim().toUpperCase());
            } catch (IllegalArgumentException e) {
                logger.warning("[PickaxeDrill] Drill '" + id + "' blocks.mode '" + modeRaw
                        + "' is invalid. Falling back to BLACKLIST.");
            }
            for (String raw : section.getStringList("materials")) {
                Material material = SafeParse.material(logger, "drill '" + id + "' blocks.materials", raw);
                if (material != null) {
                    materials.add(material);
                }
            }
        }
        return new DrillDefinition.BlockFilter(mode, materials);
    }

    private DrillDefinition.WorldSettings parseWorlds(ConfigurationSection section) {
        DrillDefinition.WorldMode mode = DrillDefinition.WorldMode.ALL;
        Set<String> list = new LinkedHashSet<>();
        if (section != null) {
            String modeRaw = section.getString("mode", "ALL");
            try {
                mode = DrillDefinition.WorldMode.valueOf(modeRaw.trim().toUpperCase());
            } catch (IllegalArgumentException e) {
                logger.warning("[PickaxeDrill] worlds.mode '" + modeRaw + "' is invalid. Falling back to ALL.");
            }
            list.addAll(section.getStringList("list"));
        }
        return new DrillDefinition.WorldSettings(mode, list);
    }

    private DrillDefinition.ParticleSettings parseParticles(String id, ConfigurationSection section) {
        if (section == null || !section.getBoolean("enabled", false)) {
            return new DrillDefinition.ParticleSettings(false, null, 0, 0, 0, 0, 0);
        }
        Particle type = SafeParse.particle(logger, "drill '" + id + "' particles.type", section.getString("type"));
        if (type == null) {
            return new DrillDefinition.ParticleSettings(false, null, 0, 0, 0, 0, 0);
        }
        return new DrillDefinition.ParticleSettings(
                true, type,
                Math.max(0, section.getInt("count", 10)),
                section.getDouble("offset-x", 0.2),
                section.getDouble("offset-y", 0.2),
                section.getDouble("offset-z", 0.2),
                section.getDouble("speed", 0.1)
        );
    }

    private DrillDefinition.SoundSettings parseSounds(String id, ConfigurationSection section) {
        if (section == null || !section.getBoolean("enabled", false)) {
            return new DrillDefinition.SoundSettings(false, null, 1f, 1f);
        }
        Sound sound = SafeParse.sound(logger, "drill '" + id + "' sounds.sound", section.getString("sound"));
        if (sound == null) {
            return new DrillDefinition.SoundSettings(false, null, 1f, 1f);
        }
        return new DrillDefinition.SoundSettings(
                true, sound,
                (float) section.getDouble("volume", 1.0),
                (float) section.getDouble("pitch", 1.0)
        );
    }

    public Map<String, DrillDefinition> getDrills() {
        return drills;
    }

    public MessagesConfig getMessages() {
        return messages;
    }

    public int getGlobalMaxSize() {
        return globalMaxSize;
    }

    public boolean isDebugEnabled() {
        return debugEnabled;
    }

    public boolean isAutoReload() {
        return autoReload;
    }
}
