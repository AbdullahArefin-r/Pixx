package com.pickaxedrill.config;

import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemFlag;
import net.kyori.adventure.text.Component;

import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Fully parsed, immutable configuration for a single drill id (e.g. "diamond", or any
 * custom id an admin invents). One instance of this class represents everything the plugin
 * needs to know to identify, craft, and operate that drill - nothing about drill behavior
 * is hard-coded in Java; it all originates from config.yml via {@link ConfigManager}.
 */
public final class DrillDefinition {

    public final String id;
    public final boolean enabled;

    public final ItemSettings item;
    public final RecipeSettings recipe;
    public final int miningSize;
    public final DurabilitySettings durability;
    public final BlockFilter blockFilter;
    public final SneakSettings sneak;
    public final PermissionSettings permission;
    public final WorldSettings worlds;
    public final CooldownSettings cooldown;
    public final ParticleSettings particles;
    public final SoundSettings sounds;
    public final ModeSettings modes;
    public final boolean mainHandOnly;

    public DrillDefinition(String id, boolean enabled, ItemSettings item, RecipeSettings recipe,
                            int miningSize, DurabilitySettings durability, BlockFilter blockFilter,
                            SneakSettings sneak, PermissionSettings permission, WorldSettings worlds,
                            CooldownSettings cooldown, ParticleSettings particles, SoundSettings sounds,
                            ModeSettings modes, boolean mainHandOnly) {
        this.id = id;
        this.enabled = enabled;
        this.item = item;
        this.recipe = recipe;
        this.miningSize = miningSize;
        this.durability = durability;
        this.blockFilter = blockFilter;
        this.sneak = sneak;
        this.permission = permission;
        this.worlds = worlds;
        this.cooldown = cooldown;
        this.particles = particles;
        this.sounds = sounds;
        this.modes = modes;
        this.mainHandOnly = mainHandOnly;
    }

    public record ItemSettings(Material material, Component name, List<Component> lore,
                                Integer customModelData, Map<Enchantment, Integer> enchantments,
                                Set<ItemFlag> itemFlags, boolean unbreakable) {
    }

    public record RecipeSettings(boolean enabled, List<String> shape, Map<Character, Material> ingredients) {
    }

    public record DurabilitySettings(boolean enabled, int amountPerUse, boolean preventBreaking) {
    }

    public enum FilterMode { BLACKLIST, WHITELIST }

    public record BlockFilter(FilterMode mode, Set<Material> materials) {
        public boolean isAllowed(Material material) {
            boolean inList = materials.contains(material);
            return mode == FilterMode.BLACKLIST ? !inList : inList;
        }
    }

    public record SneakSettings(boolean required, boolean disableWhileSneaking) {
    }

    public record PermissionSettings(boolean enabled, String node) {
    }

    public enum WorldMode { ALL, WHITELIST, BLACKLIST }

    public record WorldSettings(WorldMode mode, Set<String> list) {
        public boolean isAllowed(String worldName) {
            return switch (mode) {
                case ALL -> true;
                case WHITELIST -> list.contains(worldName);
                case BLACKLIST -> !list.contains(worldName);
            };
        }
    }

    public record CooldownSettings(boolean enabled, long milliseconds) {
    }

    public record ParticleSettings(boolean enabled, Particle type, int count,
                                    double offsetX, double offsetY, double offsetZ, double speed) {
    }

    public record SoundSettings(boolean enabled, Sound sound, float volume, float pitch) {
    }

    public record ModeSettings(boolean survival, boolean creative, boolean adventure) {
    }
}
