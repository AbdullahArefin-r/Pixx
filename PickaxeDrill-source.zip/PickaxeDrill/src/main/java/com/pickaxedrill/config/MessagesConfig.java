package com.pickaxedrill.config;

import java.util.Map;

/**
 * Holds the raw (unparsed) message strings from config.yml, keyed by their config name.
 * Kept raw here (parsed to Component lazily by MessageManager) so an empty string can be
 * cleanly detected and treated as "message disabled".
 */
public record MessagesConfig(Map<String, String> raw) {

    public String get(String key) {
        return raw.getOrDefault(key, "");
    }

    public boolean isEnabled(String key) {
        return !get(key).isBlank();
    }
}
