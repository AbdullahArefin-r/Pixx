package com.pickaxedrill.drill;

import com.pickaxedrill.config.DrillDefinition;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

/**
 * Builds the ItemStack representation of a drill and provides robust, rename-proof
 * identification via PersistentDataContainer (spec section 8 / 25) rather than relying on
 * display name or lore, both of which a player can change with an anvil.
 */
public final class DrillItemFactory {

    public static final String PDC_KEY = "drill_type";

    private final NamespacedKey drillTypeKey;

    public DrillItemFactory(org.bukkit.plugin.Plugin plugin) {
        this.drillTypeKey = new NamespacedKey(plugin, PDC_KEY);
    }

    public NamespacedKey getDrillTypeKey() {
        return drillTypeKey;
    }

    /** Builds a fresh, correctly-tagged ItemStack for the given drill definition. */
    public ItemStack create(DrillDefinition definition) {
        ItemStack item = new ItemStack(definition.item.material());
        ItemMeta meta = item.getItemMeta();

        meta.displayName(definition.item.name());
        meta.lore(definition.item.lore());

        if (definition.item.customModelData() != null) {
            meta.setCustomModelData(definition.item.customModelData());
        }

        definition.item.enchantments().forEach((enchantment, level) ->
                meta.addEnchant(enchantment, level, true));

        definition.item.itemFlags().forEach(meta::addItemFlags);

        meta.setUnbreakable(definition.item.unbreakable());

        meta.getPersistentDataContainer().set(drillTypeKey, PersistentDataType.STRING, definition.id);

        item.setItemMeta(meta);
        return item;
    }

    /** Returns the drill id tagged on this item, or null if it isn't a drill (or has no meta). */
    public String getDrillId(ItemStack item) {
        if (item == null || item.getType().isAir() || !item.hasItemMeta()) {
            return null;
        }
        ItemMeta meta = item.getItemMeta();
        return meta.getPersistentDataContainer().get(drillTypeKey, PersistentDataType.STRING);
    }

    public boolean isDrill(ItemStack item) {
        return getDrillId(item) != null;
    }
}
