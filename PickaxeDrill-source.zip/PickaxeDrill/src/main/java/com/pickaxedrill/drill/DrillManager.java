package com.pickaxedrill.drill;

import com.pickaxedrill.config.ConfigManager;
import com.pickaxedrill.config.DrillDefinition;
import org.bukkit.inventory.ItemStack;

import java.util.Map;
import java.util.Optional;

/**
 * Central registry: resolves an ItemStack to its DrillDefinition (if it is a currently-known,
 * currently-enabled drill), and exposes all loaded definitions. This is the single source of
 * truth other managers consult - nothing else keeps its own copy of "which items are drills".
 */
public final class DrillManager {

    private final ConfigManager configManager;
    private final DrillItemFactory itemFactory;

    public DrillManager(ConfigManager configManager, DrillItemFactory itemFactory) {
        this.configManager = configManager;
        this.itemFactory = itemFactory;
    }

    public DrillItemFactory getItemFactory() {
        return itemFactory;
    }

    public Map<String, DrillDefinition> getAllDrills() {
        return configManager.getDrills();
    }

    /**
     * Resolves an ItemStack to its DrillDefinition, using PDC tagging so renaming via anvil
     * never breaks detection. Returns empty if the item isn't a drill, or if it's tagged with
     * a drill id that no longer exists in the current config (e.g. removed after a reload).
     */
    public Optional<DrillDefinition> resolve(ItemStack item) {
        String id = itemFactory.getDrillId(item);
        if (id == null) {
            return Optional.empty();
        }
        return Optional.ofNullable(configManager.getDrills().get(id));
    }
}
