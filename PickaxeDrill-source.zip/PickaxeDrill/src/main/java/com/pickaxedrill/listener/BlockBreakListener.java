package com.pickaxedrill.listener;

import com.pickaxedrill.config.DrillDefinition;
import com.pickaxedrill.drill.DrillManager;
import com.pickaxedrill.manager.CooldownManager;
import com.pickaxedrill.manager.DurabilityManager;
import com.pickaxedrill.manager.MessageManager;
import com.pickaxedrill.manager.ParticleManager;
import com.pickaxedrill.manager.SoundManager;
import com.pickaxedrill.mining.MiningManager;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.inventory.ItemStack;

import java.util.Optional;

/**
 * The main gameplay hook. Every real (client-initiated) block break passes through here first;
 * this class decides whether a drill should activate and, if so, orchestrates mining the extra
 * blocks, playing effects, applying the single durability change, and enforcing cooldowns,
 * permissions, world restrictions, sneak rules, and the center-block filter.
 *
 * Synthetic BlockBreakEvents fired by {@link MiningManager} for the *extra* blocks also pass
 * through this same listener (since Bukkit dispatches every registered handler for every
 * event of that type) - the {@code isProcessing()} recursion guard makes sure those never
 * trigger a second, nested drill activation (spec section 23).
 */
public final class BlockBreakListener implements Listener {

    private final DrillManager drillManager;
    private final MiningManager miningManager;
    private final DurabilityManager durabilityManager;
    private final CooldownManager cooldownManager;
    private final ParticleManager particleManager;
    private final SoundManager soundManager;
    private final MessageManager messageManager;

    public BlockBreakListener(DrillManager drillManager, MiningManager miningManager,
                               DurabilityManager durabilityManager, CooldownManager cooldownManager,
                               ParticleManager particleManager, SoundManager soundManager,
                               MessageManager messageManager) {
        this.drillManager = drillManager;
        this.miningManager = miningManager;
        this.durabilityManager = durabilityManager;
        this.cooldownManager = cooldownManager;
        this.particleManager = particleManager;
        this.soundManager = soundManager;
        this.messageManager = messageManager;
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBlockBreak(BlockBreakEvent event) {
        // Recursion guard: never re-enter drill logic for the synthetic events we fire
        // ourselves while mining the extra blocks of an in-progress activation.
        if (miningManager.isProcessing()) {
            return;
        }

        Player player = event.getPlayer();

        // In vanilla Minecraft only the main-hand item is ever used to break blocks, so this
        // naturally already satisfies "main-hand-only" drill behavior; the config flag exists
        // for completeness/documentation (see README) rather than changing behavior here.
        ItemStack tool = player.getInventory().getItemInMainHand();

        Optional<DrillDefinition> maybeDrill = drillManager.resolve(tool);
        if (maybeDrill.isEmpty()) {
            return; // Not a drill - behaves exactly like a normal pickaxe (spec section 26).
        }
        DrillDefinition definition = maybeDrill.get();
        String displayName = PlainTextComponentSerializer.plainText().serialize(definition.item.name());

        if (!definition.enabled) {
            messageManager.send(player, "drill-disabled", displayName);
            return;
        }

        if (definition.permission.enabled() && !player.hasPermission(definition.permission.node())) {
            messageManager.send(player, "no-permission", displayName);
            return;
        }

        if (!definition.worlds.isAllowed(player.getWorld().getName())) {
            messageManager.send(player, "world-disabled", displayName);
            return;
        }

        if (!isModeAllowed(definition, player.getGameMode())) {
            return;
        }

        boolean sneaking = player.isSneaking();
        if (definition.sneak.required() && !sneaking) {
            messageManager.send(player, "sneak-required", displayName);
            return;
        }
        if (!definition.sneak.required() && definition.sneak.disableWhileSneaking() && sneaking) {
            messageManager.send(player, "sneak-disables", displayName);
            return;
        }

        if (definition.cooldown.enabled()
                && !cooldownManager.isReady(player.getUniqueId(), definition.id, definition.cooldown.milliseconds())) {
            messageManager.send(player, "cooldown", displayName);
            return;
        }

        Block center = event.getBlock();
        if (!definition.blockFilter.isAllowed(center.getType())) {
            // Center block itself is blacklisted (or not whitelisted) - drill does not
            // activate at all; vanilla single-block break still proceeds normally
            // (spec section 11).
            return;
        }

        // All checks passed - activate the drill.
        BlockFace face = miningManager.resolveFace(player, center);
        Location centerLocation = center.getLocation();

        miningManager.mineExtraBlocks(player, center, face, definition, tool);

        durabilityManager.registerPending(player.getUniqueId(),
                definition.durability.enabled(), definition.durability.amountPerUse(),
                definition.durability.preventBreaking());

        particleManager.play(definition, centerLocation);
        soundManager.play(definition, player, centerLocation);

        if (definition.cooldown.enabled()) {
            cooldownManager.recordActivation(player.getUniqueId(), definition.id);
        }
    }

    private boolean isModeAllowed(DrillDefinition definition, GameMode mode) {
        return switch (mode) {
            case SURVIVAL -> definition.modes.survival();
            case CREATIVE -> definition.modes.creative();
            case ADVENTURE -> definition.modes.adventure();
            case SPECTATOR -> false; // Spectators can never break blocks anyway.
        };
    }
}
