package com.pickaxedrill.listener;

import com.pickaxedrill.config.DrillDefinition;
import com.pickaxedrill.drill.DrillManager;
import com.pickaxedrill.manager.DurabilityManager;
import com.pickaxedrill.manager.MessageManager;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerItemDamageEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.Damageable;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.Optional;

/**
 * Rewrites the single vanilla durability-damage event that follows a drill activation so that
 * the whole activation (regardless of how many blocks were actually mined) costs exactly the
 * drill's configured {@code durability.amount-per-use} - see {@link DurabilityManager} for the
 * full explanation of why this works and how it interacts with Unbreaking.
 */
public final class DurabilityListener implements Listener {

    private final DrillManager drillManager;
    private final DurabilityManager durabilityManager;
    private final MessageManager messageManager;

    public DurabilityListener(DrillManager drillManager, DurabilityManager durabilityManager,
                               MessageManager messageManager) {
        this.drillManager = drillManager;
        this.durabilityManager = durabilityManager;
        this.messageManager = messageManager;
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onItemDamage(PlayerItemDamageEvent event) {
        Player player = event.getPlayer();
        Optional<DurabilityManager.PendingOverride> maybeOverride =
                durabilityManager.consumePending(player.getUniqueId());
        if (maybeOverride.isEmpty()) {
            return; // Not a drill activation's durability event - leave vanilla behavior alone.
        }
        DurabilityManager.PendingOverride override = maybeOverride.get();

        if (!override.enabled()) {
            event.setCancelled(true);
            return;
        }

        // Respect Unbreaking's own chance-based protection: if vanilla already rolled 0 damage
        // for this hit, leave it at 0 rather than forcing our configured amount through.
        if (event.getDamage() <= 0) {
            return;
        }

        ItemStack item = event.getItem();
        int finalDamage = durabilityManager.clampForPreventBreaking(item, override.amount(), override.preventBreaking());
        event.setDamage(finalDamage);

        maybeSendDurabilityWarning(player, item, finalDamage);
    }

    private void maybeSendDurabilityWarning(Player player, ItemStack item, int appliedDamage) {
        ItemMeta meta = item.getItemMeta();
        if (!(meta instanceof Damageable damageable)) {
            return;
        }
        int maxDurability = item.getType().getMaxDurability();
        if (maxDurability <= 0) {
            return;
        }
        int newDamage = damageable.getDamage() + appliedDamage;
        if (newDamage >= maxDurability - 1) {
            drillManager.resolve(item).ifPresent(definition -> {
                String displayName = PlainTextComponentSerializer.plainText().serialize(definition.item.name());
                messageManager.send(player, "durability-warning", displayName);
            });
        }
    }
}
