package com.pickaxedrill.manager;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Tracks per-player, per-drill-id last-activation timestamps to enforce each drill's
 * (optional) cooldown, preventing accidental rapid repeated activations.
 */
public final class CooldownManager {

    private final Map<String, Long> lastActivation = new ConcurrentHashMap<>();

    private String key(UUID playerId, String drillId) {
        return playerId + ":" + drillId;
    }

    /** Returns true if the player may activate this drill right now (and does NOT itself record activation). */
    public boolean isReady(UUID playerId, String drillId, long cooldownMillis) {
        Long last = lastActivation.get(key(playerId, drillId));
        if (last == null) {
            return true;
        }
        return System.currentTimeMillis() - last >= cooldownMillis;
    }

    /** Records that the drill was just activated, starting its cooldown window. */
    public void recordActivation(UUID playerId, String drillId) {
        lastActivation.put(key(playerId, drillId), System.currentTimeMillis());
    }

    public void clearPlayer(UUID playerId) {
        lastActivation.keySet().removeIf(k -> k.startsWith(playerId + ":"));
    }
}
