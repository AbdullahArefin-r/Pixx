package com.pickaxedrill.manager;

import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.Damageable;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Guarantees exactly ONE durability calculation per drill activation (spec sections 10 & 24),
 * no matter how many blocks that activation mines.
 *
 * How it works: when {@link com.pickaxedrill.listener.BlockBreakListener} decides a drill
 * activation is happening, it registers a pending override for that player *before* mining
 * the extra blocks. Vanilla Minecraft will, immediately after the originally-targeted block
 * finishes breaking, fire exactly one {@code PlayerItemDamageEvent} for the tool (this already
 * respects the Unbreaking enchantment's chance-based protection). Our
 * {@link com.pickaxedrill.listener.DurabilityListener} intercepts that single event and asks
 * this manager to rewrite its damage amount to the drill's configured total, instead of the
 * vanilla default of 1 - so the *one* vanilla-triggered durability event becomes the *one and
 * only* durability change for the whole activation, deliberately never touched again for the
 * other blocks the drill also mined (which are broken via Block#breakNaturally, which does not
 * itself fire durability events).
 *
 * If Unbreaking's own probability roll already reduced vanilla's damage to 0 for this hit, we
 * respect that and leave it at 0 rather than forcing our configured amount through - this keeps
 * Unbreaking's per-use protection meaningful instead of bypassing it.
 */
public final class DurabilityManager {

    public record PendingOverride(boolean enabled, int amount, boolean preventBreaking) {
    }

    private final Map<UUID, PendingOverride> pending = new ConcurrentHashMap<>();

    public void registerPending(UUID playerId, boolean enabled, int amount, boolean preventBreaking) {
        pending.put(playerId, new PendingOverride(enabled, amount, preventBreaking));
    }

    public Optional<PendingOverride> consumePending(UUID playerId) {
        return Optional.ofNullable(pending.remove(playerId));
    }

    public void clearPending(UUID playerId) {
        pending.remove(playerId);
    }

    /**
     * Given the intended final damage value and prevent-breaking behavior, returns the damage
     * value that should actually be applied, clamped so the item is never allowed to reach or
     * exceed its max durability when preventBreaking is true.
     */
    public int clampForPreventBreaking(ItemStack item, int intendedDamage, boolean preventBreaking) {
        if (!preventBreaking) {
            return intendedDamage;
        }
        ItemMeta meta = item.getItemMeta();
        if (!(meta instanceof Damageable damageable)) {
            return intendedDamage;
        }
        int maxDurability = item.getType().getMaxDurability();
        if (maxDurability <= 0) {
            return intendedDamage;
        }
        int currentDamage = damageable.getDamage();
        int wouldBeDamage = currentDamage + intendedDamage;
        if (wouldBeDamage >= maxDurability) {
            // Hold the item at 1 durability point remaining instead of letting it break.
            int clamped = Math.max(0, (maxDurability - 1) - currentDamage);
            return clamped;
        }
        return intendedDamage;
    }
}
