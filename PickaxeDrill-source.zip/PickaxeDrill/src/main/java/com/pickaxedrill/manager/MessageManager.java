package com.pickaxedrill.manager;

import com.pickaxedrill.config.MessagesConfig;
import com.pickaxedrill.util.TextUtil;
import org.bukkit.entity.Player;

/**
 * Sends the configurable messages from config.yml's "messages" section. A message set to an
 * empty string is treated as disabled and is silently skipped, per spec section 29.
 */
public final class MessageManager {

    private volatile MessagesConfig messages;

    public MessageManager(MessagesConfig messages) {
        this.messages = messages;
    }

    /**
     * Swaps in a freshly-loaded MessagesConfig (e.g. after a config reload) without changing
     * object identity - listeners hold a reference to this same MessageManager instance for
     * the plugin's whole lifetime, so this is the only way a reload's new messages reach them.
     */
    public void update(MessagesConfig messages) {
        this.messages = messages;
    }

    public void send(Player player, String key) {
        send(player, key, null, null);
    }

    public void send(Player player, String key, String drillDisplayName) {
        send(player, key, drillDisplayName, null);
    }

    public void send(Player player, String key, String drillDisplayName, String extraPlaceholderValue) {
        if (!messages.isEnabled(key)) {
            return;
        }
        String raw = messages.get(key)
                .replace("{player}", player.getName());
        if (drillDisplayName != null) {
            raw = raw.replace("{drill}", drillDisplayName);
        }
        player.sendMessage(TextUtil.parse(raw));
    }
}
