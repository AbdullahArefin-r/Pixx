package com.pickaxedrill.manager;

import com.pickaxedrill.config.DrillDefinition;
import org.bukkit.Location;

/** Plays a drill's configured particle effect once, centered on the activation block. */
public final class ParticleManager {

    public void play(DrillDefinition definition, Location center) {
        DrillDefinition.ParticleSettings settings = definition.particles;
        if (!settings.enabled() || settings.type() == null || center.getWorld() == null) {
            return;
        }
        center.getWorld().spawnParticle(
                settings.type(),
                center.clone().add(0.5, 0.5, 0.5),
                settings.count(),
                settings.offsetX(), settings.offsetY(), settings.offsetZ(),
                settings.speed()
        );
    }
}
