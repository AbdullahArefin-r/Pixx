package com.pickaxedrill.manager;

import com.pickaxedrill.config.DrillDefinition;
import org.bukkit.Location;
import org.bukkit.entity.Player;

/** Plays a drill's configured sound once, to the activating player, centered on the block. */
public final class SoundManager {

    public void play(DrillDefinition definition, Player player, Location center) {
        DrillDefinition.SoundSettings settings = definition.sounds;
        if (!settings.enabled() || settings.sound() == null) {
            return;
        }
        player.playSound(center, settings.sound(), settings.volume(), settings.pitch());
    }
}
