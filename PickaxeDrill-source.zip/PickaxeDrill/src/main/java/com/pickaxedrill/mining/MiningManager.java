package com.pickaxedrill.mining;

import com.pickaxedrill.config.DrillDefinition;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.entity.Player;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

/**
 * Computes and executes the extra-block portion of a drill activation: resolving which face
 * was targeted, building the NxN plane relative to that face, filtering out blocks the drill
 * must never touch, and breaking each remaining block in a way that still respects protection
 * plugins (by manually firing a BlockBreakEvent per extra block and checking cancellation)
 * without ever re-triggering drill logic recursively.
 *
 * The originally-targeted center block is NOT handled here - it is left to vanilla / the
 * event already in progress in {@link com.pickaxedrill.listener.BlockBreakListener}. This
 * class only handles the *additional* blocks around it.
 */
public final class MiningManager {

    private final Logger logger;
    private volatile boolean debug;

    /**
     * Recursion guard (spec section 23). While true, the plugin's own BlockBreakListener will
     * not initiate a new drill activation in response to the synthetic events fired below.
     * Single-threaded/synchronous by nature of the main-thread event pipeline, so a plain
     * boolean is sufficient - no concurrency concerns.
     */
    private boolean processing = false;

    public MiningManager(Logger logger, boolean debug) {
        this.logger = logger;
        this.debug = debug;
    }

    public boolean isProcessing() {
        return processing;
    }

    /** Updates the debug-logging flag in place (used when config.yml is reloaded). */
    public void setDebug(boolean debug) {
        this.debug = debug;
    }

    /**
     * Resolves the BlockFace the player was targeting when they broke the given block. Uses a
     * ray trace first (reliable across survival and creative), falling back to a simple
     * eye-to-block heuristic if the ray trace doesn't land cleanly on the block (e.g. very
     * high latency, or the block was already gone by the time we check).
     */
    public BlockFace resolveFace(Player player, Block broken) {
        RayTraceResult result = player.rayTraceBlocks(6.0);
        if (result != null && result.getHitBlockFace() != null && result.getHitBlock() != null
                && result.getHitBlock().getLocation().equals(broken.getLocation())) {
            return result.getHitBlockFace();
        }
        return fallbackFace(player, broken);
    }

    private BlockFace fallbackFace(Player player, Block broken) {
        Vector eye = player.getEyeLocation().toVector();
        Vector center = broken.getLocation().toVector().add(new Vector(0.5, 0.5, 0.5));
        Vector diff = eye.subtract(center);
        double ax = Math.abs(diff.getX());
        double ay = Math.abs(diff.getY());
        double az = Math.abs(diff.getZ());
        if (ay >= ax && ay >= az) {
            return diff.getY() > 0 ? BlockFace.UP : BlockFace.DOWN;
        } else if (ax >= ay && ax >= az) {
            return diff.getX() > 0 ? BlockFace.EAST : BlockFace.WEST;
        } else {
            return diff.getZ() > 0 ? BlockFace.SOUTH : BlockFace.NORTH;
        }
    }

    /**
     * Breaks the extra (non-center) blocks in the drill's NxN plane. Returns the number of
     * blocks actually broken (used only for debug logging - durability is handled entirely
     * separately and exactly once, regardless of this count).
     */
    public int mineExtraBlocks(Player player, Block center, BlockFace face, DrillDefinition definition,
                                ItemStack tool) {
        List<Block> targets = computePlane(center, face, definition.miningSize);
        int brokenCount = 0;

        processing = true;
        try {
            for (Block block : targets) {
                if (!isEligible(block, definition)) {
                    continue;
                }
                BlockBreakEvent syntheticEvent = new BlockBreakEvent(block, player);
                Bukkit.getPluginManager().callEvent(syntheticEvent);
                if (syntheticEvent.isCancelled()) {
                    continue;
                }
                boolean broke = block.breakNaturally(tool, true);
                if (broke) {
                    brokenCount++;
                }
            }
        } finally {
            processing = false;
        }

        if (debug) {
            logger.info("[PickaxeDrill] Drill '" + definition.id + "' activation by " + player.getName()
                    + ": face=" + face + ", size=" + definition.miningSize
                    + ", extra blocks processed=" + brokenCount);
        }

        return brokenCount;
    }

    private boolean isEligible(Block block, DrillDefinition definition) {
        Material type = block.getType();
        if (type.isAir()) {
            return false;
        }
        if (type == Material.WATER || type == Material.LAVA) {
            return false;
        }
        if (type.getHardness() < 0) {
            // Unbreakable in vanilla terms (e.g. bedrock-like blocks not already covered by
            // the configured blacklist) - never touch these regardless of config.
            return false;
        }
        if (!block.getWorld().getWorldBorder().isInside(block.getLocation())) {
            return false;
        }
        int chunkX = block.getX() >> 4;
        int chunkZ = block.getZ() >> 4;
        if (!block.getWorld().isChunkLoaded(chunkX, chunkZ)) {
            return false;
        }
        return definition.blockFilter.isAllowed(type);
    }

    /**
     * Builds the list of blocks in the NxN plane around {@code center}, perpendicular to
     * {@code face}, excluding the center block itself (already handled by the caller).
     */
    private List<Block> computePlane(Block center, BlockFace face, int size) {
        List<Block> blocks = new ArrayList<>();
        int radius = size / 2;

        int[] axis1;
        int[] axis2;
        switch (face) {
            case UP, DOWN -> {
                axis1 = new int[]{1, 0, 0};
                axis2 = new int[]{0, 0, 1};
            }
            case NORTH, SOUTH -> {
                axis1 = new int[]{1, 0, 0};
                axis2 = new int[]{0, 1, 0};
            }
            case EAST, WEST -> {
                axis1 = new int[]{0, 1, 0};
                axis2 = new int[]{0, 0, 1};
            }
            default -> {
                // Non-cardinal face (shouldn't normally happen for a block break) - fall back
                // to a horizontal plane so the drill still does *something* sensible.
                axis1 = new int[]{1, 0, 0};
                axis2 = new int[]{0, 0, 1};
            }
        }

        for (int i = -radius; i <= radius; i++) {
            for (int j = -radius; j <= radius; j++) {
                if (i == 0 && j == 0) {
                    continue; // center block, handled by the caller/vanilla event
                }
                int dx = axis1[0] * i + axis2[0] * j;
                int dy = axis1[1] * i + axis2[1] * j;
                int dz = axis1[2] * i + axis2[2] * j;
                blocks.add(center.getRelative(dx, dy, dz));
            }
        }
        return blocks;
    }
}
