package com.pickaxedrill.recipe;

import com.pickaxedrill.config.DrillDefinition;
import com.pickaxedrill.drill.DrillItemFactory;
import com.pickaxedrill.drill.DrillManager;
import org.bukkit.Bukkit;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.ShapedRecipe;
import org.bukkit.plugin.Plugin;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

/**
 * Registers a ShapedRecipe for every enabled drill whose recipe validated successfully.
 * Idempotent: safe to call again (e.g. after a full config reload) since it removes any
 * previously-registered PickaxeDrill recipe keys first.
 */
public final class RecipeManager {

    private final Plugin plugin;
    private final Logger logger;
    private final DrillManager drillManager;
    private final DrillItemFactory itemFactory;
    private final List<NamespacedKey> registeredKeys = new ArrayList<>();

    public RecipeManager(Plugin plugin, DrillManager drillManager, DrillItemFactory itemFactory) {
        this.plugin = plugin;
        this.logger = plugin.getLogger();
        this.drillManager = drillManager;
        this.itemFactory = itemFactory;
    }

    public void registerAll() {
        unregisterAll();

        for (DrillDefinition definition : drillManager.getAllDrills().values()) {
            if (!definition.enabled || !definition.recipe.enabled()) {
                continue;
            }
            try {
                registerRecipe(definition);
            } catch (Exception e) {
                logger.warning("[PickaxeDrill] Failed to register recipe for drill '" + definition.id
                        + "': " + e.getMessage() + ". Skipping this recipe.");
            }
        }
    }

    private void registerRecipe(DrillDefinition definition) {
        NamespacedKey key = new NamespacedKey(plugin, "drill_" + definition.id);

        ItemStack result = itemFactory.create(definition);
        ShapedRecipe recipe = new ShapedRecipe(key, result);

        List<String> shape = definition.recipe.shape();
        recipe.shape(shape.toArray(new String[0]));

        definition.recipe.ingredients().forEach(recipe::setIngredient);

        Bukkit.addRecipe(recipe);
        registeredKeys.add(key);
    }

    /** Removes every recipe this manager previously registered (used before re-registering). */
    public void unregisterAll() {
        for (NamespacedKey key : registeredKeys) {
            Bukkit.removeRecipe(key);
        }
        registeredKeys.clear();
    }
}
