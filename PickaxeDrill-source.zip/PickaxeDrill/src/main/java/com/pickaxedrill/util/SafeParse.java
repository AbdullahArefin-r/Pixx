package com.pickaxedrill.util;

import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.NamespacedKey;
import org.bukkit.Registry;

import java.util.logging.Logger;

/**
 * Central place for "parse this config string into a game enum/registry value, and if it's
 * invalid, log a clear warning and return null/empty instead of throwing" - per the spec's
 * requirement that bad config values must never crash the plugin or abort loading everything
 * else.
 */
public final class SafeParse {

    private SafeParse() {
    }

    public static Material material(Logger logger, String context, String raw) {
        if (raw == null || raw.isBlank()) {
            return null;
        }
        Material material = Material.matchMaterial(raw.trim());
        if (material == null) {
            logger.warning("[PickaxeDrill] Invalid material '" + raw + "' in " + context + ". Skipping.");
        }
        return material;
    }

    public static Particle particle(Logger logger, String context, String raw) {
        if (raw == null || raw.isBlank()) {
            return null;
        }
        try {
            return Registry.PARTICLE_TYPE.get(NamespacedKey.minecraft(raw.trim().toLowerCase()));
        } catch (Exception ignored) {
            // fall through to legacy enum lookup below for older/alternate naming
        }
        try {
            return Particle.valueOf(raw.trim().toUpperCase());
        } catch (IllegalArgumentException e) {
            logger.warning("[PickaxeDrill] Invalid particle type '" + raw + "' in " + context
                    + ". Particles disabled for this drill.");
            return null;
        }
    }

    public static Sound sound(Logger logger, String context, String raw) {
        if (raw == null || raw.isBlank()) {
            return null;
        }
        try {
            return Registry.SOUNDS.get(NamespacedKey.minecraft(raw.trim().toLowerCase()));
        } catch (Exception ignored) {
            // fall through
        }
        try {
            return Sound.valueOf(raw.trim().toUpperCase());
        } catch (IllegalArgumentException e) {
            logger.warning("[PickaxeDrill] Invalid sound '" + raw + "' in " + context
                    + ". Sound disabled for this drill.");
            return null;
        }
    }

    public static Enchantment enchantment(Logger logger, String context, String raw) {
        if (raw == null || raw.isBlank()) {
            return null;
        }
        String key = raw.trim().toLowerCase();
        Enchantment enchantment = Registry.ENCHANTMENT.get(NamespacedKey.minecraft(key));
        if (enchantment == null) {
            logger.warning("[PickaxeDrill] Invalid enchantment '" + raw + "' in " + context + ". Skipping.");
        }
        return enchantment;
    }

    public static ItemFlag itemFlag(Logger logger, String context, String raw) {
        if (raw == null || raw.isBlank()) {
            return null;
        }
        try {
            return ItemFlag.valueOf(raw.trim().toUpperCase());
        } catch (IllegalArgumentException e) {
            logger.warning("[PickaxeDrill] Invalid item flag '" + raw + "' in " + context + ". Skipping.");
            return null;
        }
    }
}
