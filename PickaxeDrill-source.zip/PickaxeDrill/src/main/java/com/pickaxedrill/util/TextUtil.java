package com.pickaxedrill.util;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import net.kyori.adventure.text.format.TextDecoration;

import java.util.List;
import java.util.regex.Pattern;

/**
 * Converts config strings into Adventure Components, auto-detecting whether the string
 * uses MiniMessage tags ("<aqua>...") or legacy ampersand color codes ("&b...").
 *
 * A string is treated as MiniMessage if it contains something that looks like a tag
 * (e.g. "<something>"); otherwise it is parsed as legacy. This lets server owners mix
 * whichever syntax they're comfortable with, per-string, without any extra config.
 */
public final class TextUtil {

    private static final Pattern MINIMESSAGE_TAG = Pattern.compile("<[a-zA-Z0-9_#/][^<>]*>");
    private static final MiniMessage MINI_MESSAGE = MiniMessage.miniMessage();
    private static final LegacyComponentSerializer LEGACY = LegacyComponentSerializer.legacyAmpersand();

    private TextUtil() {
    }

    /**
     * Parses a single string as either MiniMessage or legacy '&' codes, and strips the
     * default italic that Minecraft normally applies to item names/lore so text renders
     * as authored.
     */
    public static Component parse(String raw) {
        if (raw == null) {
            return Component.empty();
        }
        Component component;
        if (MINIMESSAGE_TAG.matcher(raw).find()) {
            component = MINI_MESSAGE.deserialize(raw);
        } else {
            component = LEGACY.deserialize(raw);
        }
        return component.decorationIfAbsent(TextDecoration.ITALIC, TextDecoration.State.FALSE);
    }

    public static List<Component> parseList(List<String> raw) {
        return raw.stream().map(TextUtil::parse).toList();
    }
}
